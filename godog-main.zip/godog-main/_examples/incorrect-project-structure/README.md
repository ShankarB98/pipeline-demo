This example is to help reproduce issue [#383](https://github.com/cucumber/godog/issues/383)

To run the example: 

    cd _examples/incorrect-project-structure
    go run ../../cmd/godog