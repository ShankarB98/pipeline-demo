package main

import "github.com/cucumber/godog"

func InitializeScenario(ctx *godog.ScenarioContext) {

}
