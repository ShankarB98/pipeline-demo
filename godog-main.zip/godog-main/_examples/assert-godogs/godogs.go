package main

// Godogs available to eat
var Godogs int

func main() { /* usual main func */ }
