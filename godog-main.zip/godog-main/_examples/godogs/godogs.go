package godogs

// Godogs available to eat.
var Godogs int
