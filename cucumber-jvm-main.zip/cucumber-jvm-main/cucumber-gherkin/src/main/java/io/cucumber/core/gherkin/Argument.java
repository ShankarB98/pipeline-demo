package io.cucumber.core.gherkin;

import io.cucumber.plugin.event.StepArgument;

public interface Argument extends StepArgument {

}
