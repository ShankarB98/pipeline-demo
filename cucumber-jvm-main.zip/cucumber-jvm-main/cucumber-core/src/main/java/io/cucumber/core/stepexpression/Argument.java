package io.cucumber.core.stepexpression;

public interface Argument {

    Object getValue();

    String toString();

}
