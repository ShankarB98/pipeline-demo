package io.cucumber.core.backend;

public interface Options {

    Class<? extends ObjectFactory> getObjectFactoryClass();

}
