package io.cucumber.core.runtime;

import io.cucumber.core.runner.Runner;

public interface RunnerSupplier {

    Runner get();

}
