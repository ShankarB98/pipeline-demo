package io.cucumber.core.snippets;

import java.util.List;

interface Joiner {

    String concatenate(List<String> words);

}
