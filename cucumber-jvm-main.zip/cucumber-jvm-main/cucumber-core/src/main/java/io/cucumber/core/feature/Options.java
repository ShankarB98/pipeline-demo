package io.cucumber.core.feature;

import java.net.URI;
import java.util.List;

public interface Options {

    List<URI> getFeaturePaths();

}
