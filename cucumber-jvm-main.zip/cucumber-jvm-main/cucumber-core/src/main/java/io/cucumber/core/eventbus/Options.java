package io.cucumber.core.eventbus;

public interface Options {

    Class<? extends UuidGenerator> getUuidGeneratorClass();

}
