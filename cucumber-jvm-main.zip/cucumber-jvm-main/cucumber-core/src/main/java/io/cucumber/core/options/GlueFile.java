package io.cucumber.core.options;

class GlueFile {

}
