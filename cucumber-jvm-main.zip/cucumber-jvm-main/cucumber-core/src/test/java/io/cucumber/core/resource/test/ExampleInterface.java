package io.cucumber.core.resource.test;

public interface ExampleInterface {

}
