package io.cucumber.core.resource.test;

public class OtherClass {

}
