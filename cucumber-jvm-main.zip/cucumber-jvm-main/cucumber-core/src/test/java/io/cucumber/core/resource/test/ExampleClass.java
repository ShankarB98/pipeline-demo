package io.cucumber.core.resource.test;

public class ExampleClass implements ExampleInterface {

}
