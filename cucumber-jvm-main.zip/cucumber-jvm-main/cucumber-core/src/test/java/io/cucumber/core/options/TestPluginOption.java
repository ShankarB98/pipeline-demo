package io.cucumber.core.options;

public class TestPluginOption {

    public static PluginOption parse(String pluginArgumentPattern) {
        return PluginOption.parse(pluginArgumentPattern);
    }

}
