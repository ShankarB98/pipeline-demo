package io.cucumber.core.cli;

public class MainDemo {

    public static void main(String[] args) {
        // Main.main("--i18n");
        // Main.main("--i18n", "help");
        Main.main("--i18n", "tlh");
    }

}
