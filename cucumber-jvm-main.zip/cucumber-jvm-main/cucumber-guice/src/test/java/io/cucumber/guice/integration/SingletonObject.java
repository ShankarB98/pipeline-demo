package io.cucumber.guice.integration;

public class SingletonObject {

}
